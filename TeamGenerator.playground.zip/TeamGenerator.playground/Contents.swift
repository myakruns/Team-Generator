//: Playground - noun: a place where people can play

/* Basic group generator.  
This application will create random groups from a list of names.  The primary functions of this level are:
 1 - enter names by hand or spreadsheet
 2 - select max number per group or the number of groups
 3 - create evenly sized groups by random selection - DONE
 
 Iteration 1:
 - use an array constant
 
 Iteration 2:
 - enter names by hand
 
 Iteration 3:
 - load in spreadsheet
 
 Iteration 4:
 - iOS app

 7/3/16 - 9:45
 creates balanced teams.  Next step is randomize list
 
 */

import UIKit
import GameplayKit

// Set the class list in an array
var classList: [String] = ["Student 1", "Student 2", "Student 3", "Student 4", "Student 5", "Student 6", "Student 7", "Student 8", "Student 9", "Student 10", "Student 11", "Student 12", "Student 13", "Student 14", "Student 15", "Student 16", "Student 17", "Student 18", "Student 19", "Student 20", "Student 21", "Student 22", "Student 23", "Student 24", "Student 25", "Student 26", "Student 27", "Student 28", "Student 29", "Student 30", "Student 31", "Student 32", "Student 33", "Student 34", "Student 35", "Student 36", "Student 37", "Student 38", "Student 39", "Student 40", "Student 41", "Student 42", /*"Student 43", "Student 44", "Student 45", "Student 46", "Student 47", "Student 48", "Student 49", "Student 50"*/]


// Sets the number of groups

var groupSize = 7                           // max number of students per group
var classSize = classList.count             // counts the size of the class
var numberOfGroups = classSize/groupSize    // estimates number of groups based on groupSize
var extraMembers = classSize % groupSize    // estimates number of left over members

var numberOfMinGroups = 0                   // number of groups less than "full"
var minGroup = 0                            // number of members in a "minimum group"
var maxGroup = groupSize                    // number of members in a "maximum group"
var numberOfMaxGroups = numberOfGroups

var memberFirst = 0
var memberLast = 0
var memberIndex = 0

func runMaxGroups() {
    for group in 1...numberOfMaxGroups {
        print("Group \(group)")
        memberFirst = (group * groupSize) - groupSize
        memberLast = (group * groupSize) - 1
        for _ in memberFirst...memberLast {
            print(shuffledClass[memberIndex])
            memberIndex += 1
        }
    }
}

func runMinGroups() {
    for group in (numberOfMaxGroups+1)...numberOfGroups {
        print("Group \(group)")
        memberFirst = (group * minGroup) - minGroup
        memberLast = (group * minGroup) - 1
        for _ in memberFirst...memberLast {
            print(shuffledClass[memberIndex])
            memberIndex += 1
        }
    }
}

// creates randoom array of classList
let shuffledClass = GKRandomSource.sharedRandom().arrayByShufflingObjectsInArray(classList)

if extraMembers == 0 {
    runMaxGroups()
} else {
    numberOfGroups = (classSize/groupSize) + 1
    numberOfMinGroups = groupSize - extraMembers
    while numberOfMinGroups >= numberOfGroups {
        groupSize -= 1
        extraMembers = classSize % groupSize
        
        if extraMembers == 0 {
            numberOfGroups = classSize/groupSize
            numberOfMinGroups = 0
            numberOfMaxGroups = numberOfGroups
        } else {
            numberOfGroups = (classSize/groupSize) + 1
            numberOfMinGroups = groupSize - extraMembers
        }

    }
    
    if extraMembers == 0 {
        runMaxGroups()
    } else {
        numberOfMaxGroups = numberOfGroups - numberOfMinGroups
        minGroup = groupSize - 1
        runMaxGroups()
        runMinGroups()
    }
}







/*
if extraMembers != 0 {
    numberOfGroups = (classSize/groupSize) + 1      // Sets the number of groups for unequal distribution
} else {
    numberOfGroups = classSize/groupSize            // Sets the number of groups for equal distribution
}


// Sets the group size.
// Need to fix error for situations such as 16 students and teams of 7.  Use an loop to iterate to a solution?

var numberOfMinGroups = 0
var minGroup = 0
var maxGroup = groupSize                // Sets the largest group to the size set for max number above.  This is where the error needs to be fixed.

if extraMembers != 0 {
    numberOfMinGroups = groupSize - extraMembers    // calculates number of small groups needed for distribution
    minGroup = groupSize - 1                        // sets the size of the small groups
}

var numberOfMaxGroups = numberOfGroups - numberOfMinGroups

if numberOfMaxGroups < 1 {
    numberOfMaxGroups = 0
}

var smallGroup = numberOfMinGroups*minGroup
var largeGroup = numberOfMaxGroups*maxGroup
var totalGroup = smallGroup + largeGroup

// error check on setting group sizes
if totalGroup == classSize {
    print("correct")
} else {
    print("error")
}

// creates randoom array of classList
let shuffledClass = GKRandomSource.sharedRandom().arrayByShufflingObjectsInArray(classList)

// runs the team list
var memberFirst = 0
var memberLast = 0
var memberIndex = 0

if numberOfMaxGroups > 0 {
    for group in 1...numberOfMaxGroups {
        print("Group \(group)")
        memberFirst = (group * groupSize) - groupSize
        memberLast = (group * groupSize) - 1
        for member in memberFirst...memberLast {
            print(shuffledClass[memberIndex])
            memberIndex += 1
        }
    }
}


if numberOfMinGroups != 0 {
    for group in (numberOfMaxGroups+1)...numberOfGroups {
        print("Group \(group)")
        memberFirst = (group * minGroup) - minGroup
        memberLast = (group * minGroup) - 1
        for member in memberFirst...memberLast {
            print(shuffledClass[memberIndex])
            memberIndex += 1
        }
    }

}

*/

