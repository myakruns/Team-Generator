//: Playground - noun: a place where people can play

/* Basic group generator.  
This application will create random groups from a list of names.  The primary functions of this level are:
 1 - enter names by hand or spreadsheet
 2 - select max number per group or the number of groups
 3 - create evenly sized groups by random selection
 
 Iteration 1:
 - use an array constant
 
 Iteration 2:
 - enter names by hand
 
 Iteration 3:
 - load in spreadsheet
 
 Iteration 4:
 - iOS app

 */

import UIKit

var classList: [String] = ["Student 1", "Student 2", "Student 3", "Student 4", "Student 5", "Student 6", "Student 7", "Student 8", "Student 9", "Student 10", "Student 11", "Student 12", "Student 13", "Student 14", "Student 15", "Student 16", "Student 17", "Student 18", "Student 19", "Student 20", "Student 21", "Student 22", "Student 23", "Student 24", "Student 25", "Student 26", "Student 27", "Student 28", "Student 29", "Student 30", "Student 31", /*"Student 32"*/]

var groupSize = 4
var classSize = classList.count
var numberOfGroups = 0

if classSize % groupSize != 0 {
    numberOfGroups = (classSize/groupSize) + 1
} else {
    numberOfGroups = classSize/groupSize
}

/*
 for group in 1...numberOfGroups {
    var memberA = (group * groupSize) - 3
    var memberB = (group * groupSize) - 2
    var memberC = (group * groupSize) - 1
    print("Group \(group): \(classList[memberA]), \(classList[memberB]), \(classList[memberC])")
}
 */

var extraMembers = classSize % groupSize
var numberOfMinGroups = 0
var minGroup = 0
var maxGroup = groupSize

if extraMembers != 0 {
    numberOfMinGroups = groupSize - extraMembers
    minGroup = groupSize - 1
}

var numberOfMaxGroups = numberOfGroups - numberOfMinGroups

var smallGroup = numberOfMinGroups*minGroup
var largeGroup = numberOfMaxGroups*maxGroup
var totalGroup = smallGroup + largeGroup

if totalGroup == classSize {
    print("correct")
} else {
    print("error")
}

var memberFirst = 0
var memberLast = 0
var memberIndex = 0
for group in 1...numberOfMaxGroups {
    print("Group \(group)")
    memberFirst = (group * groupSize) - groupSize
    memberLast = (group * groupSize) - 1
    for member in memberFirst...memberLast {
        print(classList[memberIndex])
        memberIndex += 1
    }
}

for group in (numberOfMaxGroups+1)...numberOfGroups {
    print("Group \(group)")
    memberFirst = (group * minGroup) - minGroup
    memberLast = (group * minGroup) - 1
    for member in memberFirst...memberLast {
        print(classList[memberIndex])
        memberIndex += 1
    }
}